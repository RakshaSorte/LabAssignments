package labbook9;

import java.util.Scanner;

interface MyInterface
{
double power(int x,int y);
}
public  class lab1 {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("enter first number");
int a=sc.nextInt();
System.out.println("enter second number");
int b=sc.nextInt();
MyInterface m3=(x,y)->Math.pow(x,y);
double x=m3.power(a,b);
System.out.print(x);

		}


	}
