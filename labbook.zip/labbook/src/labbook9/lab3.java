package labbook9;


import java.util.Scanner;


interface validity
{
	boolean authentication(String str1,String str2);
}
public class lab3 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter username");
	String s1 = sc.next();
	System.out.println("Enter password");
	String s2 = sc.next();
	validity p=(x,y)->x.equals("raksha") && y.equals("123");
	System.out.println("Result:"+p.authentication(s1, s2));

}
}

