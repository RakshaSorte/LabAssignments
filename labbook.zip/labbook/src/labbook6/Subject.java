package labbook6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Subject {
public static void main(String args[])
{
List<String> subjects=new ArrayList<String>() ;
subjects.add("java");
subjects.add("python");
subjects.add("sap");
subjects.add("spring");

Scanner sc=new Scanner (System.in);
System.out.println("Enter a subject");
String sub=sc.nextLine();

 boolean flag=subjects.contains(sub);
 System.out.println("using contains method.....");
 if(flag)
	 System.out.println(" The List contains entered subject");
 else
	 System.out.println("The List  does not contains entered subject");
 
System.out.println("using Iterator.....");
 
Iterator<String> i =subjects.iterator();

while(i.hasNext())
{
	String subject =i.next();
	if(sub.equals(subject))
		System.out.println("The List contains entered subject");
	    break;
	
}

	



}
}
