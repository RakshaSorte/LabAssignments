package com.cg.training.lab4.exercise3.client;

import com.cg.training.lab4.exercise3.service.*;

public class Tester {

	public static void main(String[] args) {
		

		CD cd = new CD(101, "JK", 1, 9, "ABC", "Comedy");
		cd.print();
		cd.checkOut();
		cd.print();
		
	}

}
