package com.cg.training.lab4.exercise3.service;



public class Book extends WrittenItem
{
	public Book(int idNum, String title, int numCopies, String author) {
		super(idNum, title, numCopies, author);
	}
}
