package com.cg.labbook3;



import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;


class lab5
{
public static void main(String args[])throws IOException
{
   int n1=1,n2=0;           
     char ch;               
Scanner scr=new Scanner(System.in);
  System.out.print("File name: ");
 String str=scr.nextLine();
   FileInputStream f=new FileInputStream(str);
 int n=f.available();
for(int i=0;i<n;i++)
{

    ch=(char)f.read();
    if(ch=='\n')
    n1++;
    else if(ch==' ')
     n2++;                     
 }
         System.out.println("\nNumber of lines : "+n1);
         System.out.println("\nNumber of words : "+(n1+n2));
         System.out.println("\nNumber of characters : "+n);
}
}

