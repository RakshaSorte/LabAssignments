package com.cg.labbook3;
import java.util.Scanner;
public class lab4 {
public static void main(String[] args) {
// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);
System.out.print("Enter a number: ");
int num= sc.nextInt();
Integer obj=new Integer(num);
String str=obj.toString();
System.out.println(str);
int n=str.length();
char c[]=new char[n];
int a[]=new int[n];
int dif[]=new int[n-1];
for(int i=0;i<n;i++) {
c[i]=str.charAt(i);
}
for(int i=0;i<c.length;i++) {
String b=(String) String.valueOf(c[i]);
a[i]=Integer.parseInt(String.valueOf(b));
System.out.println(a[i]);
}
StringBuffer sbf1 = new StringBuffer();
for(int i=0;i<a.length;i++) {
dif[i]=a[i]-a[i+1];
System.out.println(dif[i]);
}
}
}
