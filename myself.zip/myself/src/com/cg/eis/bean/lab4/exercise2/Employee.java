package com.cg.eis.bean.lab4.exercise2;

public class Employee {
	private Integer id;
	private String name;
	private Double salary;
	private String designation;
	private String insuranceScheme;
	
	public Employee() {
		super();
	}

	public Employee(Integer id, String name, Double salary, String designation, String insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public String getInsuranceScheme() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getDesignation() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setSalary(Double sal) {
		// TODO Auto-generated method stub
		
	}

	public void setDesignation(String desig) {
		// TODO Auto-generated method stub
		
	}
}
