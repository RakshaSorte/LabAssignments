package com.cg.eis.service.lab4.exercise2;

import com.cg.eis.bean.lab4.exercise2.Employee;

public interface EmployeeService {

	void getDetails(Employee e);
	void findInsuranceScheme(Employee e);
	void displayDetails(Employee e);
}
