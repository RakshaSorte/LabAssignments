package com.cg.labbook5;

public class AgeException extends Exception {

	public AgeException(String arg0) {
		super(arg0);
		
	}

	
}