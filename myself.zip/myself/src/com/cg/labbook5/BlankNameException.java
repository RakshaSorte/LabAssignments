package com.cg.labbook5;
public class BlankNameException extends Exception {

	public BlankNameException(String string) {
	super(string);
	}

}