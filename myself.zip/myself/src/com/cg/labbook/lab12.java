package com.cg.labbook;
import java.util.Scanner;
public class lab12 {
	private static final int Red=0;
	private static final int Yellow=1;
	private static final int Green=2;

	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("your choice");
		int ch=s.nextInt();
		switch(ch)
		{
		case Red:
			System.out.println("Stop");
			break;
		case Yellow:
			System.out.println("Ready");
			break;
		case Green:
			System.out.println("Go");
					break;
		}

	}
	}

