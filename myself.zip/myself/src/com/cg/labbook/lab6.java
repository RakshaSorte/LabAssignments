package com.cg.labbook;
import java.util.Scanner;
public class lab6 {
public static void main(String args[]) {
	       int n;
	       boolean flag = false;
	       Scanner sc = new Scanner(System.in);
	       System.out.println("Enter a number");
	       n = sc.nextInt();
	       int d =n % 10;
	       n =n/10;
	       while(n>0){
	          if(d<= n% 10){
	               flag = true;
	               break;
	           }
	           d = n% 10;
	           n= n/10;
	       }
	       if(flag){
	           System.out.println("Digits are not in increasing orde.");
	       }else{
	           System.out.println("Digits are in increasing order");
	       }
	    }
	}
