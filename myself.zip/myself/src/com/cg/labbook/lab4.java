package com.cg.labbook;

public class lab4 {
	      
	    static void result(int n) 
	    {      

	        for (int num = 0; num <n; num++) 
	        {      
	            
	            if (num % 3 == 0 && num % 5 == 0) 
	                System.out.print(num + " "); 
	        } 
	    } 
	       
	   
	    public static void main(String []args) 
	    { 
	    
	        int n = 100; 
	           
	
	        result(n); 
	    } 
	}
